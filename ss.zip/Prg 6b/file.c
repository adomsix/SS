void main()
{
int a= 80;
float b;
char d;
if(a=80)
{
printf("good");
}
else 
{
printf("bad");
}
}
