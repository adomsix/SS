#include<stdio.h>

int main() {
	float x = 1.0;
	x = x + 2.0;
	for (int i = 0; i < 22; i++)
		x -= 0.02;
	printf("Imposter number");
}
