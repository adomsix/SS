#include "y.tab.c"
#include <stdio.h>

int main()
{
printf("\n enter the expression\n");
yyparse();

}
