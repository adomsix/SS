cc 5.c
./a.out input.txt
