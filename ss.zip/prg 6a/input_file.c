#include<stdio.h>

int main() {
	// This is a sample C program
	/* using different comment styles */
	/* multiline is 
	  done it think
	 */

	printf("yamete kudasi");
}
