gcc 4.c
./a.out
