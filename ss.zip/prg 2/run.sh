lex 2.l
yacc -d 2.y
cc lex.yy.c y.tab.c -ll -w
./a.out
